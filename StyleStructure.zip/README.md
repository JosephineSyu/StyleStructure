# Style-Structure
@keyframes shimmer {
    0%, 100% 
}
